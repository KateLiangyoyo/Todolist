import "./styles.css";
import React, { useEffect } from "react";
import "./styles.css";
import InputField from "./components/InputField";
import TodosList from "./components/TodosList";
import { connect } from "react-redux";
import { deleteAll,persistTodos } from "./redux/action/addTodo.action";
const App =({deleteAll,persistTodos}) => {
  useEffect(() =>{
persistTodos();
  },[persistTodos]);
  return (
    <div className="App">
      <h1 style={{ textDecoration: "underline" }}> Todos App</h1>
      <InputField />
      <TodosList />
      <div>
        <button style={{marginTop:'200px',cursor:'pointer'}} 
        onClick={deleteAll}>{" "}delete all</button>
      </div>
    </div>
  );
}
const mapDispatchToProps = dispatch => ({
  deleteAll : () => dispatch(deleteAll()),
  persistTodos: () => dispatch(persistTodos())
})
export default connect(
  null,
  mapDispatchToProps)(App);